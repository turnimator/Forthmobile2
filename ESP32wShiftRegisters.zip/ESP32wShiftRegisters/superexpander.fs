
18 constant P2S_CE
19 constant P2S_SHLD
3 constant   P2S_SCK
23 constant P2S_SDA

4 constant S2P_SDA
16 constant S2P_LATCH
17 constant S2P_SCL

15 constant M_PWMA
5 constant M_PWMB

21 constant I2C_SDA
22 constant I2C_SCL

13 constant CNT_RESET

14 constant XSHUT1
27 constant XSHUT2
26 constant XSHUT3


